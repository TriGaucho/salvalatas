# 4ALL Graph API de Integração  
  
A API da 4All para integração tem base na línguagem de comunicação [GraphQL](docs/GraphQL.md).

* Development Tools
* [Graph Esquema](https://4alltecnologia.gitlab.io/dxco/integration-api-docs/schema/)
* [GraphQL Playground com Mockery](https://marketplace-graph-api-mokery-ezsper.4all.now.sh)

# Outras Referências
* [Autenticação](docs/Autenticação.md)