package com.moviestore.model;

public enum Status {
	RENTED, RETURNED;
}
